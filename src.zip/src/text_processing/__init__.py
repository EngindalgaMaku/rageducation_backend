# This file makes the 'text_processing' directory a Python package.

from .text_chunker import chunk_text

__all__ = ["chunk_text"]